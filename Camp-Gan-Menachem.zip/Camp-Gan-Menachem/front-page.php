<?php
get_header();
?>
  <div class="welcome">
    <h3> Welcome! <br>
      Please Choose a Division Below:</h3>
  </div>
  <div class="spacer"></div>
 <!-- Css Grid Div --> 
<!--<div class="grid-container">

<!-<div class="button">-->
<!--Css Flexbox-->
<div class="flex-container">
  <div><button class="item2 button button1">
   <a href="/youngerdivision"> Younger Division </a> </button></div>
      <div> <button class="item4 button button2"> 
        <a href="/olderdivision">Older Division </a> </button></div>
 </div>

<!-- End Of Css Grid  
</div>-->

<!--</div>-->

