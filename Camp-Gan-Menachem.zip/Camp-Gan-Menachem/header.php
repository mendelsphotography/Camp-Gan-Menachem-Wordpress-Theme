<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta --> 
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/x-icon" href="/assets/images/Logo.jpg">
  <?php
 wp_head();
 ?>
   <!--<a href=./> <img src="/assets/images/Logo.jpg" alt="Logo"> </a>-->


    <!--<nav>
      <ul>
        <li> <a href="/">Home</a> </li>
        <li> <a href="/contact.html">Contact</a> </li>
        <li> <a href="/about.html">About</a> </li>
        <li> <a href="/blog.html">Blog</a> </li>
      </ul>

    </nav> -->
  </div>

<nav>
  <ul>
    <div class="flex-container1">
      <a href= /><img class="Logo1" src="/assets/images/Logo.jpg" alt="Logo"></a>
      <h2 class="text  camp">Camp Gan Menachem 5781</h2>
      <div>
        <li class="home"><a href="/">Home</a></li>
      </div>
      <div>
        <li class="contac"><a href="/contact">Contact</a></li>
      </div>
      <div>
        <li class="abou"><a href="/about">About</a></li>
      </div>
      <div>
        <li class="blo"><a href="/blog">Blog</a> </li>
      </div>
    </div>
  </ul>


</nav>


</head>